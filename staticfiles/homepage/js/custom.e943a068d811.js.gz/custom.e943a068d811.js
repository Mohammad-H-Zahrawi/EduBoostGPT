$(document).ready(function(){
    $('#btn-print-this').click(function(){
        $('#container11').printThis();
    });
});